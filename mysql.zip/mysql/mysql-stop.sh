# go to docker-compose.yml directory
cd ./docker-compose.yml

# Stop the containers
docker-compose down -v

echo "Docker containers are stopped."